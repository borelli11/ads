#!/usr/bin/env python3
"""
Gera um CONTEUDO.docx a partir da peça, na ordem de leitura.

PARA QUE SERVE: montar pacote de teste. O arquivo sai com o texto do código e
o texto lido das imagens, cada um na posição em que aparece — que é exatamente
o que o CONTEUDO.docx deveria ter.

PARA QUE NÃO SERVE: conferir a peça. Comparar este arquivo com a mesma peça
sempre dá 100%, porque os dois lados saíram da mesma leitura. Validação de
verdade exige o docx escrito pelo redator.

IMPORTANTE: o texto sai com o motor de OCR DESTA máquina. Um docx gerado num
computador com RapidOCR e conferido noutro com o OCR do Windows acusa
divergência em cada acento — os dois leem certo, só escrevem diferente. Gere o
arquivo na mesma máquina em que for conferir.

Uso:
    python gerar_conteudo.py "C:\\pacotes\\MINHA_CAMPANHA"
    python gerar_conteudo.py "C:\\pacotes\\MINHA_CAMPANHA" --saida CONTEUDO_GERADO.docx
"""

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from validador import html_parser, pacote  # noqa: E402
from validador.ocr import CacheOCR, motor_ativo, ocr_disponivel  # noqa: E402


def gerar(pasta: str, saida: str | None = None) -> str:
    from docx import Document

    encontrados = pacote.localizar_pacotes(pasta)
    if not encontrados:
        raise SystemExit(f"Não encontrei um pacote em: {pasta}")
    raiz = encontrados[0]

    htmls = pacote._localizar_html(raiz)
    if not htmls:
        raise SystemExit("O pacote não tem nenhum arquivo .html")
    caminho_html = htmls[0]

    referencias = html_parser.ler_html(caminho_html, raiz).imagens_referenciadas
    pasta_imagens = pacote._localizar_pasta_imagens(raiz, caminho_html, referencias)

    disponivel, motivo = ocr_disponivel()
    cache = CacheOCR() if disponivel else None
    if not disponivel:
        print(f"  Atenção: sem leitura de imagens ({motivo}).")
        print("  O arquivo sairá só com o texto escrito no código.\n")

    leitura = html_parser.ler_html(caminho_html, pasta_imagens, cache_ocr=cache)

    documento = Document()
    linhas = 0
    for bloco in leitura.fita:
        # o pré-header fica numa div oculta e pertence ao docx de assunto,
        # não ao de conteúdo
        if bloco.oculto or not bloco.conteudo:
            continue
        for linha in bloco.conteudo.splitlines():
            if linha.strip():
                documento.add_paragraph(linha.strip())
                linhas += 1

    destino = saida or os.path.join(raiz, "CONTEUDO_GERADO.docx")
    if not os.path.isabs(destino):
        destino = os.path.join(raiz, destino)
    documento.save(destino)

    motor = motor_ativo()
    print(f"  Pacote:   {os.path.basename(raiz)}")
    print(f"  Peça:     {os.path.basename(caminho_html)}")
    print(f"  Motor:    {motor.descricao if motor else 'nenhum'}")
    print(f"  Gerado:   {destino}  ({linhas} parágrafos)")
    return destino


def main():
    p = argparse.ArgumentParser(
        description="Gera um CONTEUDO.docx a partir da peça, para montar pacote de teste."
    )
    p.add_argument("pasta", help="pasta do pacote")
    p.add_argument("--saida", help="nome do arquivo de saída")
    args = p.parse_args()

    print()
    gerar(args.pasta, args.saida)
    print()
    print("  Lembre: este arquivo serve para TESTAR o validador, não para")
    print("  conferir a peça — os dois lados saíram da mesma leitura.")
    print()


if __name__ == "__main__":
    main()
