"""
Comparação por presença, usada quando o texto das imagens não pôde ser lido.

Sem OCR, a fita do HTML fica incompleta: o texto dos banners some, mas continua
no CONTEUDO.docx. Comparar sequência nessa condição alinha trecho errado com
trecho errado e produz apontamento que não existe.

Aqui a pergunta é outra e mais honesta: cada trecho de texto vivo do HTML
aparece no docx? Sobra no docx não é cobrada, porque quase sempre é o texto das
imagens que não conseguimos ler.

Espaçamento, quebra de linha e divisão de parágrafo não contam — a comparação é
palavra a palavra.
"""

from dataclasses import dataclass, field
from difflib import SequenceMatcher

from . import correcao_ocr, ordenacao
from .comparador import Divergencia
from .normalizacao import tokenizar

# trechos muito curtos geram ruído; abaixo disso só checamos presença das palavras
MINIMO_PARA_SEQUENCIA = 3


@dataclass
class ResultadoPresenca:
    similaridade: float = 0.0
    divergencias: list[Divergencia] = field(default_factory=list)
    trechos_dispensados: list[str] = field(default_factory=list)
    obrigatorios_ausentes: list[str] = field(default_factory=list)
    blocos_sem_ocr: list[str] = field(default_factory=list)
    blocos_conferidos: int = 0
    correcoes_ocr: list[str] = field(default_factory=list)
    imagens_reordenadas: list[str] = field(default_factory=list)
    comparacao_parcial: bool = True
    total_tokens_html: int = 0
    total_tokens_docx: int = 0
    tokens_iguais: int = 0

    @property
    def status(self) -> str:
        if any(d.gravidade == "alta" for d in self.divergencias):
            return "reprovado"
        return "parcial"

    @property
    def aprovado(self) -> bool:
        return False  # nunca aprova: parte da peça não foi conferida

    def por_gravidade(self, nivel):
        return [d for d in self.divergencias if d.gravidade == nivel]


def _indice_da_subsequencia(sub: list[str], universo: list[str]) -> int:
    """Procura a sequência exata de palavras dentro do docx."""
    if not sub or len(sub) > len(universo):
        return -1
    primeiro = sub[0]
    limite = len(universo) - len(sub) + 1
    for i in range(limite):
        if universo[i] == primeiro and universo[i:i + len(sub)] == sub:
            return i
    return -1


def _paragrafo_mais_proximo(tokens: list[str], paragrafos: list[str]) -> str:
    """
    Acha o parágrafo do docx que mais se parece com o trecho da peça.

    A citação precisa ser o parágrafo inteiro, do jeito que está no arquivo:
    é isso que a pessoa vai colar no report para mostrar a divergência sem
    precisar dizer qual dos dois está certo.
    """
    alvo = set(tokens)
    if not alvo:
        return ""

    notas = []
    for indice, paragrafo in enumerate(paragrafos):
        palavras = set(tokenizar(paragrafo))
        if not palavras:
            continue
        # cobertura: quanto do parágrafo do docx está no trecho da peça.
        # Usar cobertura em vez de similaridade evita descartar um parágrafo
        # curto ("Banco Exemplo") só por ser menor que o bloco da peça.
        cobertura = len(alvo & palavras) / len(palavras)
        if cobertura >= 0.5:
            notas.append((indice, paragrafo))

    if not notas:
        return ""

    # Cita a faixa contínua entre o primeiro e o último parágrafo que casaram.
    # Quando algo entrou no meio — o caso de ordem trocada — é justamente essa
    # linha intrusa que explica o apontamento, e ela só aparece se a citação
    # não pular buracos.
    indices = [i for i, _ in notas]
    inicio, fim = min(indices), max(indices)
    if fim - inicio > 6:
        return "\n".join(paragrafos[i] for i in sorted(indices)[:5])
    return "\n".join(paragrafos[inicio:fim + 1])


def comparar(fita, paragrafos_docx: list[str]) -> ResultadoPresenca:
    resultado = ResultadoPresenca()

    tokens_docx = []
    for paragrafo in paragrafos_docx:
        tokens_docx.extend(tokenizar(paragrafo))
    # a busca compara em forma canônica, que absorve as confusões de caractere
    # do OCR (0/o, 1/l); o relatório continua exibindo o texto original
    tokens_docx = [correcao_ocr.canonizar(t) for t in tokens_docx]
    conjunto_docx = set(tokens_docx)
    vocabulario = conjunto_docx
    resultado.total_tokens_docx = len(tokens_docx)

    # mesma ideia do modo completo: dentro da imagem, a ordem que vale é a do
    # docx, não a que o OCR inferiu do layout
    for bloco in fita:
        if bloco.tipo == "imagem" and bloco.conteudo and bloco.ocr_lido:
            ajuste = ordenacao.alinhar_por_referencia(bloco.conteudo, paragrafos_docx)
            if ajuste.reordenou:
                bloco.conteudo = "\n".join(ajuste.linhas)
                bloco.reordenado = True
                resultado.imagens_reordenadas.append(bloco.referencia or "imagem")

    vistos_sem_leitura = set()
    tokens_html_total = 0
    tokens_encontrados = 0

    for bloco in fita:
        if bloco.oculto:
            continue

        if bloco.tipo == "imagem" and not bloco.ocr_lido:
            nome = bloco.referencia or "imagem"
            if nome not in vistos_sem_leitura:
                vistos_sem_leitura.add(nome)
                resultado.blocos_sem_ocr.append(nome)
            continue

        tokens = tokenizar(bloco.conteudo)
        # Mesmo com imagens faltando, as que FORAM lidas passam pela correção:
        # sem isto, "nasuaconta" e "a0" viram apontamento falso justamente no
        # modo em que o sistema já está conferindo menos.
        if bloco.tipo == "imagem" and bloco.ocr_lido:
            tokens, separados = correcao_ocr.corrigir(tokens, vocabulario)
            resultado.correcoes_ocr.extend(separados)
        if not tokens:
            continue
        # duas versões: a canônica busca, a original aparece no relatório.
        # Sem isso o diff mostraria "R$ so ooo oo" no lugar de "R$ 50 000 00".
        exibicao = list(tokens)
        tokens = [correcao_ocr.canonizar(t) for t in tokens]

        tokens_html_total += len(tokens)
        origem = bloco.referencia if bloco.tipo == "imagem" else "texto vivo"
        obrigatorio = ""
        if bloco.classificacao.startswith("obrigatorio"):
            obrigatorio = bloco.classificacao.split(":", 1)[1]
        tolerado = bloco.classificacao == "tolerado"

        # texto de template: só é cobrado se o analista tiver escrito no docx
        if bloco.classificacao == "dispensavel":
            resultado.trechos_dispensados.append(bloco.conteudo)
            tokens_encontrados += len(tokens)
            continue

        resultado.blocos_conferidos += 1

        # 1. sequência exata no docx: caso perfeito
        if (len(tokens) >= MINIMO_PARA_SEQUENCIA
                and _indice_da_subsequencia(tokens, tokens_docx) >= 0):
            tokens_encontrados += len(tokens)
            continue

        # 2. todas as palavras existem, mas não juntas nessa ordem
        ausentes = [exibicao[i] for i, t in enumerate(tokens) if t not in conjunto_docx]
        if not ausentes:
            tokens_encontrados += len(tokens)
            if len(tokens) >= MINIMO_PARA_SEQUENCIA:
                resultado.divergencias.append(Divergencia(
                    tipo="fora_de_ordem",
                    origem=origem,
                    trecho_html=" ".join(exibicao[:25]),
                    trecho_docx="as mesmas palavras aparecem no docx, em outra ordem",
                    obrigatorio=obrigatorio,
                    tolerado=tolerado,
                    citacao_html=bloco.conteudo,
                    citacao_docx=_paragrafo_mais_proximo(tokens, paragrafos_docx),
                ))
            continue

        # 3. faltam palavras: apontamento real
        tokens_encontrados += len(tokens) - len(ausentes)
        melhor = _trecho_mais_parecido(tokens, tokens_docx)
        divergencia = Divergencia(
            tipo="faltando",
            origem=origem,
            trecho_html=" ".join(exibicao[:25]),
            trecho_docx=melhor,
            contexto_antes="palavras ausentes: " + ", ".join(ausentes[:12]),
            obrigatorio=obrigatorio,
            tolerado=tolerado,
            citacao_html=bloco.conteudo,
            citacao_docx=_paragrafo_mais_proximo(tokens, paragrafos_docx),
        )
        resultado.divergencias.append(divergencia)
        if obrigatorio:
            resultado.obrigatorios_ausentes.append(
                f"{obrigatorio}: {divergencia.trecho_html}"
            )

    resultado.total_tokens_html = tokens_html_total
    resultado.tokens_iguais = tokens_encontrados
    resultado.similaridade = (
        round(tokens_encontrados / tokens_html_total * 100, 1) if tokens_html_total else 0.0
    )
    return resultado


def _trecho_mais_parecido(tokens: list[str], universo: list[str]) -> str:
    """Acha no docx o trecho mais próximo, para mostrar lado a lado no relatório."""
    if not universo:
        return "—"
    matcher = SequenceMatcher(None, universo, tokens, autojunk=False)
    bloco = matcher.find_longest_match(0, len(universo), 0, len(tokens))
    if bloco.size == 0:
        return "trecho não localizado no docx"
    inicio = max(0, bloco.a - 3)
    fim = min(len(universo), bloco.a + bloco.size + 3)
    return " ".join(universo[inicio:fim])
