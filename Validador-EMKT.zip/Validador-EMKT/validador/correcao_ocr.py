"""
Correção dos erros típicos de OCR, antes de comparar.

Motor de OCR erra de dois jeitos previsíveis em peça de e-mail:

  1. cola palavras vizinhas      "SemconsultaaoSPCeSerasa"
  2. troca caractere parecido    "ate l dia" (leu 1 como L), "a0 mes"

Se comparar sem tratar isso, quase toda imagem vira apontamento falso e o
sistema perde a serventia — você voltaria a conferir tudo no olho.

A saída aqui é usar o próprio CONTEUDO.docx como dicionário. Ele tem a grafia
correta do que deveria estar na peça: quando um pedaço colado se decompõe
exatamente em palavras do docx, foi erro de leitura, não divergência real.

O que NÃO é corrigido: número que existe de verdade. "48" contra "60" continua
divergência, porque a correção só aceita reescrita que case com o docx, e
nenhuma confusão conhecida transforma 4 em 6 ou 8 em 0.
"""

from .normalizacao import tokenizar

# caracteres que os motores confundem com frequência
CONFUSOES = str.maketrans({
    "0": "o", "1": "l", "5": "s", "8": "b",
    "|": "l", "¦": "l", "!": "l",
})

TAMANHO_MINIMO_PARA_SEGMENTAR = 6
# Uma linha inteira de banner pode vir colada ("dinheironacontaemateldiautil"
# são oito palavras). O teto existe só para evitar decomposições absurdas; a
# exigência de que TODO pedaço exista no docx já é a trava de verdade.
MAXIMO_DE_PEDACOS = 12


def canonizar(token: str) -> str:
    """
    Forma usada só para decidir se dois tokens são o mesmo.

    Nunca é exibida no relatório: o que aparece na tela continua sendo o texto
    original, para você conseguir localizar o trecho na peça.
    """
    return token.translate(CONFUSOES)


def _segmentar(colado: str, vocabulario: set[str]) -> list[str] | None:
    """
    Tenta quebrar um token colado em palavras que existam no docx.

    Programação dinâmica simples: para cada posição, guarda a menor quantidade
    de pedaços que chega até ali. Preferir menos pedaços evita decompor uma
    palavra legítima em partículas ("consulta" virando "con" + "sul" + "ta").
    """
    n = len(colado)
    melhor: list[list[str] | None] = [None] * (n + 1)
    melhor[0] = []

    for fim in range(1, n + 1):
        for inicio in range(fim - 1, -1, -1):
            if melhor[inicio] is None:
                continue
            pedaco = colado[inicio:fim]
            if len(pedaco) < 2 and pedaco not in vocabulario:
                continue
            if pedaco not in vocabulario:
                continue
            candidato = melhor[inicio] + [pedaco]
            if len(candidato) > MAXIMO_DE_PEDACOS:
                continue
            if melhor[fim] is None or len(candidato) < len(melhor[fim]):
                melhor[fim] = candidato

    resultado = melhor[n]
    return resultado if resultado and len(resultado) > 1 else None


def construir_vocabulario(paragrafos: list[str]) -> set[str]:
    """Todas as palavras do docx, em forma canônica."""
    vocabulario = set()
    for paragrafo in paragrafos:
        for palavra in tokenizar(paragrafo):
            vocabulario.add(canonizar(palavra))
    return vocabulario


def corrigir(tokens: list[str], vocabulario: set[str]) -> tuple[list[str], list[str]]:
    """
    Devolve (tokens corrigidos, lista do que foi separado).

    Só mexe no token que não existe no docx e que se decompõe inteiramente em
    palavras do docx. Qualquer outro caso passa intacto — na dúvida, o sistema
    deixa a divergência aparecer em vez de escondê-la com uma correção criativa.
    """
    saida, separados = [], []
    for token in tokens:
        canonico = canonizar(token)
        if canonico in vocabulario:
            saida.append(token)
            continue
        # caractere solto que não existe no docx é sujeira de leitura: uma borda
        # lida como parêntese, um pingo lido como ponto. Manter só produz
        # apontamento falso.
        if len(canonico) == 1:
            separados.append(f"{token} → removido (ruído de leitura)")
            continue
        if len(canonico) < TAMANHO_MINIMO_PARA_SEGMENTAR:
            saida.append(token)
            continue
        pedacos = _segmentar(canonico, vocabulario)
        if pedacos:
            saida.extend(pedacos)
            separados.append(f"{token} → {' '.join(pedacos)}")
        else:
            saida.append(token)
    return saida, separados


def tokens_iguais(a: str, b: str) -> bool:
    return canonizar(a) == canonizar(b)
