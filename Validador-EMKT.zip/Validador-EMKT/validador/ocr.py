"""
Leitura do texto contido nas imagens.

Três motores, testados em cascata. O sistema usa o primeiro que estiver
disponível na máquina, sem você precisar configurar nada:

  1. windows   — OCR nativo do Windows 10/11. Não instala binário nenhum:
                 o motor já faz parte do sistema operacional e o idioma
                 português normalmente já vem junto. Só precisa do pacote
                 Python `winocr`. É o caminho de menor atrito em máquina
                 corporativa, porque não há software novo para homologar.

  2. rapidocr  — modelos ONNX que vêm dentro do próprio pacote pip (~16 MB).
                 Roda offline depois de instalado, não precisa de binário
                 externo nem de privilégio de administrador. É o plano B
                 quando o item 1 não estiver disponível.

  3. tesseract — o mais conhecido, mas exige instalar um programa separado.
                 Aceita também versão portátil: aponte a variável de ambiente
                 TESSERACT_CMD para o executável e não precisa de instalador.

Para forçar um motor específico, defina a variável OCR_MOTOR com "windows",
"rapidocr" ou "tesseract".
"""

import os
import re
import unicodedata
from dataclasses import dataclass, field

from .normalizacao import limpar


@dataclass
class ResultadoOCR:
    arquivo: str
    texto: str = ""
    lido: bool = False
    erro: str = ""
    aviso: str = ""
    motor: str = ""
    confianca_media: float = 0.0
    linhas: list[str] = field(default_factory=list)


# ---------------------------------------------------------------- utilidades

def _preparar(caminho: str, largura_minima: int = 0):
    """
    Abre a imagem e corrige orientação.

    O aumento de escala NÃO acontece aqui: quem amplia é o fatiamento, já com
    a faixa recortada. Ampliar duas vezes só borra a letra.
    """
    from PIL import Image, ImageOps

    img = Image.open(caminho)
    img = ImageOps.exif_transpose(img)
    if img.mode not in ("L", "RGB"):
        img = img.convert("RGB")
    if largura_minima and img.width < largura_minima:
        fator = largura_minima / img.width
        # LANCZOS de propósito: o padrão do resize borra a borda das letras e o
        # motor passa a inventar caractere — "Simular agora" virava "Simular a
        # agora" num upscale de apenas 1,1x.
        img = img.resize(
            (int(img.width * fator), int(img.height * fator)), Image.LANCZOS
        )
    return img


MAXIMO_FRAMES_LIDOS = 10
# Fração mínima de pixels que precisa mudar para o frame contar como cena nova.
# Média de diferença não serve aqui: em banner de fundo claro, trocar a frase
# inteira mexe em poucos por cento dos pixels e a média mal se move.
MUDANCA_MINIMA_ENTRE_FRAMES = 0.01   # 1% dos pixels
DIFERENCA_POR_PIXEL = 40             # 0-255: o quanto um pixel precisa mudar


def _assinatura(imagem):
    """Miniatura em cinza usada só para comparar frames entre si."""
    from PIL import Image
    return list(imagem.convert("L").resize((64, 64), Image.BILINEAR).getdata())


def _frames_relevantes(caminho: str) -> list:
    """
    Escolhe quais frames de um GIF vale a pena ler.

    Um GIF de peça costuma ter dezenas de frames para poucas cenas de texto:
    ler todos custaria mais de um minuto por imagem sem acrescentar nada. Aqui
    só entram os frames que mudaram de verdade em relação ao último lido, e no
    máximo dez — o suficiente para pegar todas as cenas de uma peça de e-mail.
    """
    from PIL import Image, ImageSequence

    imagem = Image.open(caminho)
    total = getattr(imagem, "n_frames", 1)
    if total <= 1:
        return [imagem.convert("RGB")]

    escolhidos, ultima = [], None
    for quadro in ImageSequence.Iterator(imagem):
        atual = quadro.convert("RGB")
        assinatura = _assinatura(atual)
        if ultima is not None:
            mudados = sum(
                1 for a, b in zip(assinatura, ultima)
                if abs(a - b) > DIFERENCA_POR_PIXEL
            )
            if mudados / len(assinatura) < MUDANCA_MINIMA_ENTRE_FRAMES:
                continue
        escolhidos.append(atual.copy())
        ultima = assinatura
        if len(escolhidos) >= MAXIMO_FRAMES_LIDOS:
            break
    return escolhidos or [imagem.convert("RGB")]


def _juntar_textos(blocos: list[str]) -> str:
    """
    Junta o texto das cenas do GIF sem repetir o que já apareceu.

    Dois tipos de repetição acontecem aqui. A primeira é a frase que se repete
    em frames vizinhos — basta descartar a igual. A segunda é a animação de
    digitação, em que a mesma frase entra aos pedaços: "COMPROMISSO", depois
    "e TRANSPA", depois "e TRANSPARENCIA com sua empresa". Guardar todos os
    pedaços encheria a fita de fragmentos que não existem no docx, então fica
    só a versão mais completa de cada frase.
    """
    from .normalizacao import tokenizar

    candidatos = []
    for bloco in blocos:
        for linha in bloco.splitlines():
            limpa = linha.strip()
            chave = "".join(tokenizar(limpa))   # sem espaços: o OCR varia neles
            if not chave:
                continue
            candidatos.append((chave, limpa))

    # descarta o que está contido em outra linha — o pedaço da animação
    finais = []
    for chave, texto in candidatos:
        contido_em_outro = any(
            chave != outra and chave in outra for outra, _ in candidatos
        )
        if contido_em_outro:
            continue
        if any(chave == vista for vista, _ in finais):
            continue
        finais.append((chave, texto))

    return "\n".join(texto for _, texto in finais)


# O detector do motor encolhe a imagem inteira para caber em cerca de 960 px no
# lado maior. Peça de e-mail é uma tira alta e estreita: uma fatia de 900x2600
# é reduzida a 900x960 e o texto de 20 px vira 7 px — ilegível. Ler em faixas
# preserva a resolução do texto.
ALTURA_MAXIMA_POR_FATIA = 900
SOBREPOSICAO_ENTRE_FATIAS = 120   # px repetidos, para não cortar linha no meio
ALTURA_MINIMA_DO_TEXTO = 26       # abaixo disso o reconhecimento erra caractere
CONFIANCA_PARA_ALERTAR = 80       # abaixo disso a imagem entra em Observações


# Peça de e-mail é cheia de ícone e pictograma — calendário, cadeado, cifrão,
# selo. O detector não sabe distinguir desenho de letra: ele acha uma forma
# parecida com texto e o reconhecedor devolve o palpite mais próximo. O
# calendário desta campanha virava "口" numa escala e "D000 000" na outra.
# Formatos que aparecem de verdade em peça e que NÃO têm letra nenhuma. Eles
# costumam ser o dado mais importante da imagem — o percentual da oferta, a
# data da estreia, o telefone da central — e não podem ser descartados por
# falta de letra.
RE_CONTEUDO_SEM_LETRA = re.compile(r"""
      ^\d{1,3}\s?%$                                   # 50%   20 %
    | ^\d{1,2}[/.\-]\d{1,2}([/.\-]\d{2,4})?[:.]?$     # 10/09:  03/09/2026
    | ^R?\$?\s?\d{1,3}([.\s]\d{3})*([,]\d{2})?$      # R$ 50.000,00
    | ^\d{3,5}[\s-]?\d{3,4}$                          # 4002 0022 · 0800 570
    | ^\d{1,3}\s?[xX]$                                # 36x
    | ^\d{1,2}[hH]$                                    # 22h
    | ^[+\-]?\d{1,4}[.,]\d{1,2}$                      # 1,29
""", re.VERBOSE)

# Dígito ou símbolo repetido é assinatura de contorno de ícone lido como texto:
# "000", "0 0000 000", "...."
RE_REPETICAO_BOBA = re.compile(r"^([\W\d_])[\s]*(\1[\s]*)+$")

CONFIANCA_MINIMA_SEM_LETRA = 88


def _como_numero(valor, padrao: float = 0.0) -> float:
    """
    Converte para número o que o motor devolveu como confiança.

    Versões diferentes do RapidOCR entregam esse campo de jeitos diferentes:
    umas como float, outras como string ("0.98"). Comparar string com número
    quebra a leitura inteira da imagem, e o erro aparece como "sem texto lido"
    — parecendo falha do OCR quando é só um tipo diferente.
    """
    if isinstance(valor, (int, float)):
        return float(valor)
    try:
        return float(str(valor).strip().replace(",", "."))
    except (TypeError, ValueError):
        return padrao


def _tem_letra(texto: str) -> bool:
    return any(c.isalpha() for c in texto)


def _fora_do_alfabeto(texto: str) -> bool:
    """Caractere que não existe em peça escrita em português."""
    for caractere in texto:
        if caractere.isalpha() and not ("a" <= caractere.lower() <= "z"):
            # letra acentuada é latina; CJK, cirílico e afins não são
            if unicodedata.name(caractere, "").startswith("LATIN"):
                continue
            return True
        if unicodedata.category(caractere) == "So":   # símbolo/pictograma
            return True
    return False


def _e_ruido_de_icone(texto: str, confianca) -> bool:
    """
    Diz se a caixa é desenho lido como texto.

    Descartar é mais seguro do que manter: um ícone fantasma entra na
    comparação como palavra inventada e vira apontamento que ninguém consegue
    resolver, porque não existe nada para corrigir na peça.
    """
    limpo = str(texto or "").strip()
    confianca = _como_numero(confianca)
    if not limpo:
        return True
    if _fora_do_alfabeto(limpo):
        return True

    # Repetição do mesmo caractere vem antes de tudo: "000" casaria como valor
    # monetário e escaparia do filtro, mas é contorno de ícone.
    if not _tem_letra(limpo) and RE_REPETICAO_BOBA.match(limpo):
        return True

    # Percentual, data, valor e telefone ficam, custe o que custar: é o dado
    # mais importante da imagem. Descartá-los por confiança apagava justamente
    # o "50%" da oferta e o "10/09:" da estreia.
    if RE_CONTEUDO_SEM_LETRA.match(limpo.replace("  ", " ")):
        return False

    if _tem_letra(limpo):
        return len(limpo) <= 2 and confianca < CONFIANCA_MINIMA_SEM_LETRA

    # sem letra e sem formato reconhecível: só passa com confiança alta
    return confianca < CONFIANCA_MINIMA_SEM_LETRA


def _realcar(imagem):
    """
    Realça a faixa para uma segunda tentativa.

    Texto branco sobre área clara da foto — céu, parede, fachada — tem contraste
    baixo e o detector simplesmente não acha a caixa. Esticar o histograma e
    reforçar a borda das letras costuma resolver, e só roda quando a primeira
    leitura não achou nada, então não pesa no caso comum.
    """
    from PIL import ImageEnhance, ImageFilter, ImageOps

    realcada = ImageOps.autocontrast(imagem.convert("RGB"), cutoff=1)
    realcada = ImageEnhance.Contrast(realcada).enhance(1.6)
    return realcada.filter(ImageFilter.UnsharpMask(radius=2, percent=140, threshold=2))


def _fatias_da_imagem(imagem) -> list[tuple]:
    """Divide a imagem em faixas horizontais com sobreposição."""
    largura, altura = imagem.size
    limite = max(ALTURA_MAXIMA_POR_FATIA, largura)
    if altura <= limite:
        return [(imagem, 0)]

    passo = limite - SOBREPOSICAO_ENTRE_FATIAS
    fatias, topo = [], 0
    while topo < altura:
        base = min(altura, topo + limite)
        fatias.append((imagem.crop((0, topo, largura, base)), topo))
        if base >= altura:
            break
        topo += passo
    return fatias


def _caixas_em_fatias(motor, imagem, idioma: str, confianca_minima: int):
    """
    Lê a imagem em faixas e devolve as caixas já com a posição real.

    A sobreposição faz a mesma linha aparecer em duas faixas; a deduplicação
    compara texto e posição para não repetir o trecho na leitura final.
    """
    from PIL import Image

    todas = []
    fatias = _fatias_da_imagem(imagem)
    for fatia, deslocamento in fatias:
        # o reconhecimento erra caractere quando a letra fica pequena demais;
        # ampliar a faixa antes de ler recupera "50%" que virava "SOVO"
        escala = 1.0
        if fatia.width < 1400:
            escala = min(2.5, 1400 / fatia.width)
            fatia = fatia.resize(
                (int(fatia.width * escala), int(fatia.height * escala)), Image.LANCZOS
            )
        achadas = motor.caixas(fatia, idioma, confianca_minima)
        for caixa in achadas:
            for campo in ("topo", "base", "esquerda", "direita", "confianca"):
                caixa[campo] = _como_numero(caixa.get(campo, 0))
        achadas = [c for c in achadas
                   if not _e_ruido_de_icone(c["texto"], c.get("confianca", 0))]
        if not achadas:
            try:
                tentativa = motor.caixas(_realcar(fatia), idioma, confianca_minima)
            except Exception:
                tentativa = []
            tentativa = [c for c in tentativa
                         if not _e_ruido_de_icone(c["texto"], c.get("confianca", 0))]
            # o realce força o detector a achar forma onde não há texto: só
            # vale a tentativa se ela trouxer palavra de verdade
            if any(len(re.findall(r"[^\W\d_]{3,}", c["texto"])) for c in tentativa):
                achadas = tentativa
        for caixa in achadas:
            caixa["topo"] = caixa["topo"] / escala + deslocamento
            caixa["base"] = caixa["base"] / escala + deslocamento
            caixa["esquerda"] = caixa["esquerda"] / escala
            caixa["direita"] = caixa["direita"] / escala
            todas.append(caixa)

    return _remover_repetidas(todas), len(fatias)


def _remover_repetidas(itens: list[dict]) -> list[dict]:
    """Descarta caixas duplicadas pela sobreposição entre faixas vizinhas."""
    limpos = []
    for item in sorted(itens, key=lambda i: (i["topo"], i["esquerda"])):
        texto = item["texto"].strip()
        if not texto:
            continue
        repetida = False
        for anterior in limpos:
            if anterior["texto"].strip() != texto:
                continue
            if abs(anterior["topo"] - item["topo"]) < 24 and \
                    abs(anterior["esquerda"] - item["esquerda"]) < 24:
                # fica a leitura de maior confiança
                if item.get("confianca", 0) > anterior.get("confianca", 0):
                    anterior.update(item)
                repetida = True
                break
        if not repetida:
            limpos.append(item)
    return limpos


def _ordenar_linhas(itens: list[dict]) -> list[str]:
    """
    Reconstrói a ordem visual de leitura: de cima para baixo, da esquerda para
    a direita.

    Os motores devolvem caixas soltas, e duas palavras da mesma linha vêm
    separadas. Agrupar por faixa de altura fixa não funciona — título grande e
    rodapé miúdo precisam de tolerâncias diferentes. Aqui duas caixas entram na
    mesma linha quando se sobrepõem verticalmente em mais da metade da altura
    da menor delas, que é o critério que uma pessoa usaria olhando a peça.
    """
    validos = [i for i in itens if i["texto"].strip()]
    if not validos:
        return []

    for item in validos:
        item.setdefault("base", item["topo"] + item.get("altura", 10))
        item.setdefault("direita", item["esquerda"])

    validos.sort(key=lambda r: (r["topo"], r["esquerda"]))

    linhas: list[list[dict]] = []
    for item in validos:
        encaixou = False
        # Chamada de nota é uma caixa minúscula e assentada acima da linha:
        # ela mal encosta no texto ao lado. Com o mesmo critério das palavras
        # normais ela virava uma linha só dela, e o "2" de "36x²" acabava
        # solto, longe da palavra a que pertence.
        curta = len(item["texto"].strip()) <= 2
        for linha in linhas:
            topo_linha = min(c["topo"] for c in linha)
            base_linha = max(c["base"] for c in linha)
            sobreposicao = min(base_linha, item["base"]) - max(topo_linha, item["topo"])
            menor_altura = min(base_linha - topo_linha, item["base"] - item["topo"])
            # A ordenação é por topo, e a chamada de nota fica ACIMA da linha:
            # ela chega primeiro e vira âncora. Por isso o limiar reduzido vale
            # também quando é a linha existente que é só a marca de nota.
            linha_curta = all(len(c["texto"].strip()) <= 2 for c in linha)
            limiar = 0.15 if (curta or linha_curta) else 0.5
            if menor_altura > 0 and sobreposicao > menor_altura * limiar:
                linha.append(item)
                encaixou = True
                break
        if not encaixou:
            linhas.append([item])

    linhas.sort(key=lambda l: min(c["topo"] for c in l))
    saida = []
    for linha in linhas:
        linha.sort(key=lambda c: c["esquerda"])
        saida.append(_montar_linha(linha))
    return saida


RE_CHAMADA_DE_NOTA = re.compile(r"^[0-9]{1,2}$|^\*{1,3}$")


def _montar_linha(caixas: list[dict]) -> str:
    """
    Junta as caixas de uma linha, colando a chamada de nota na palavra anterior.

    O motor devolve o "2" de "CDB²" como uma caixa separada, e juntar tudo com
    espaço produziria "CDB 2". O docx traz "CDB2", porque o Word cola o
    sobrescrito — a diferença viraria apontamento em toda peça com nota de
    rodapé, que em banco é praticamente toda peça.

    O que identifica a chamada: texto de um ou dois dígitos (ou asterisco),
    caixa visivelmente menor que a anterior e assentada mais alto que ela.
    """
    partes = []
    anterior = None
    vistos_na_linha = []
    for caixa in caixas:
        texto = caixa["texto"].strip()
        if not texto:
            continue
        colar = False
        if anterior is not None and RE_CHAMADA_DE_NOTA.match(texto):
            altura = caixa["base"] - caixa["topo"]
            altura_anterior = anterior["base"] - anterior["topo"]
            distancia = caixa["esquerda"] - anterior.get("direita", anterior["esquerda"])
            mais_alta = caixa["topo"] < anterior["topo"]
            menor = altura_anterior > 0 and altura < altura_anterior * 0.8
            perto = distancia < altura_anterior * 0.8
            colar = menor and mais_alta and perto
        # A sobreposição entre faixas faz a mesma frase ser lida duas vezes, e
        # o acento muda entre as leituras ("Seducäo" e "Seducao"), então o
        # descarte por texto idêntico não pega. Comparar sem acento pega.
        assinatura = unicodedata.normalize("NFD", texto.lower())
        assinatura = "".join(c for c in assinatura
                             if unicodedata.category(c) != "Mn" and c.isalnum())
        if assinatura and assinatura in vistos_na_linha:
            continue
        if assinatura:
            vistos_na_linha.append(assinatura)

        partes.append(("" if colar else " ") + texto if partes else texto)
        anterior = caixa
    return "".join(partes)


# ------------------------------------------------------------------- motores

class MotorBase:
    nome = ""
    descricao = ""

    def disponivel(self) -> tuple[bool, str]:
        raise NotImplementedError

    def caixas(self, imagem, idioma: str, confianca_minima: int) -> list[dict]:
        """Devolve as caixas de texto detectadas, com posição e confiança."""
        raise NotImplementedError

    def ler(self, caminho: str, idioma: str, confianca_minima: int) -> ResultadoOCR:
        nome_arquivo = os.path.basename(caminho)
        try:
            imagem = _preparar(caminho)
        except Exception as e:
            return ResultadoOCR(arquivo=nome_arquivo, erro=str(e), motor=self.nome)

        try:
            itens, fatias = _caixas_em_fatias(self, imagem, idioma, confianca_minima)
        except Exception as e:
            return ResultadoOCR(arquivo=nome_arquivo, erro=str(e), motor=self.nome)

        linhas = _ordenar_linhas(itens)
        confiancas = [i["confianca"] for i in itens if i.get("confianca")]
        media = round(sum(confiancas) / len(confiancas), 1) if confiancas else 0.0

        avisos = []
        if fatias > 1:
            avisos.append(f"lida em {fatias} faixas")
        if not linhas:
            avisos.append("nenhum texto encontrado nesta imagem")
        elif media and media < CONFIANCA_PARA_ALERTAR:
            # transparência sobre o que a máquina não teve certeza de ler:
            # é melhor apontar a dúvida do que deixar passar como certo
            avisos.append(f"leitura incerta ({media:.0f}% de confiança), vale conferir no olho")
        return ResultadoOCR(
            arquivo=nome_arquivo, texto=limpar("\n".join(linhas)),
            lido=True, linhas=linhas, motor=self.nome, aviso="; ".join(avisos),
            confianca_media=media,
        )


class MotorWindows(MotorBase):
    """OCR embutido no Windows. Nenhum programa novo para instalar."""

    nome = "windows"
    descricao = "OCR nativo do Windows"

    def disponivel(self):
        if os.name != "nt":
            return False, "só funciona no Windows"
        try:
            import winocr  # noqa: F401
        except ImportError:
            return False, "falta o pacote Python: pip install winocr"
        return True, "ok"

    def caixas(self, imagem, idioma="por", confianca_minima=40):
        import winocr

        tag = {"por": "pt-BR", "eng": "en-US"}.get(idioma, idioma)
        try:
            resultado = winocr.recognize_pil_sync(imagem, tag)
        except Exception:
            # idioma não instalado no Windows: cai para o padrão do sistema
            resultado = winocr.recognize_pil_sync(imagem)

        linhas_brutas = (resultado.get("lines") if isinstance(resultado, dict)
                         else getattr(resultado, "lines", None))

        itens = []
        for linha in (linhas_brutas or []):
            if isinstance(linha, dict):
                texto = linha.get("text", "")
                palavras = linha.get("words", []) or []
                caixa = palavras[0].get("bounding_rect", {}) if palavras else {}
                topo, esquerda = caixa.get("y", 0), caixa.get("x", 0)
                altura, largura = caixa.get("height", 10), caixa.get("width", 10)
                if palavras:
                    ultima = palavras[-1].get("bounding_rect", {})
                    largura = max(largura, ultima.get("x", 0) + ultima.get("width", 0) - esquerda)
            else:
                texto = getattr(linha, "text", "") or ""
                palavras = getattr(linha, "words", []) or []
                topo = esquerda = 0
                altura = largura = 10
                if palavras:
                    caixa = getattr(palavras[0], "bounding_rect", None)
                    if caixa is not None:
                        topo = getattr(caixa, "y", 0)
                        esquerda = getattr(caixa, "x", 0)
                        altura = getattr(caixa, "height", 10)
                        largura = getattr(caixa, "width", 10)
            if not texto.strip():
                continue
            itens.append({
                "texto": texto, "topo": topo, "base": topo + altura,
                "esquerda": esquerda, "direita": esquerda + largura,
                "confianca": 0.0,   # o Windows não devolve confiança por linha
            })
        return itens


class MotorRapidOCR(MotorBase):
    """Modelos ONNX que vêm no próprio pacote pip. Offline, sem binário."""

    nome = "rapidocr"
    descricao = "RapidOCR (modelos embutidos, sem instalar programa)"
    _motor = None

    def disponivel(self):
        try:
            import rapidocr_onnxruntime  # noqa: F401
        except ImportError:
            return False, "falta o pacote Python: pip install rapidocr-onnxruntime"
        return True, "ok"

    def _obter(self):
        if MotorRapidOCR._motor is None:
            from rapidocr_onnxruntime import RapidOCR
            MotorRapidOCR._motor = RapidOCR()
        return MotorRapidOCR._motor

    def caixas(self, imagem, idioma="por", confianca_minima=40):
        import numpy as np

        saida, _ = self._obter()(np.array(imagem.convert("RGB")))
        if not saida:
            return []

        limite = confianca_minima / 100
        itens = []
        for registro in saida:
            caixa, texto, confianca = registro[0], registro[1], registro[2]
            confianca = _como_numero(confianca)
            if confianca < limite:
                continue
            pontos = [(_como_numero(p[0]), _como_numero(p[1])) for p in caixa]
            itens.append({
                "texto": str(texto or ""),
                "topo": min(p[1] for p in pontos),
                "base": max(p[1] for p in pontos),
                "esquerda": min(p[0] for p in pontos),
                "direita": max(p[0] for p in pontos),
                "confianca": confianca * 100,
            })
        return itens


class MotorTesseract(MotorBase):
    """Tesseract. Aceita instalação normal ou versão portátil via TESSERACT_CMD."""

    nome = "tesseract"
    descricao = "Tesseract"

    def disponivel(self):
        try:
            import pytesseract
        except ImportError:
            return False, "falta o pacote Python: pip install pytesseract"
        if os.environ.get("TESSERACT_CMD"):
            pytesseract.pytesseract.tesseract_cmd = os.environ["TESSERACT_CMD"]
        try:
            pytesseract.get_tesseract_version()
        except Exception:
            return False, "o programa Tesseract não foi encontrado na máquina"
        return True, "ok"

    def idiomas(self):
        try:
            import pytesseract
            return list(pytesseract.get_languages(config=""))
        except Exception:
            return []

    def caixas(self, imagem, idioma="por", confianca_minima=40):
        import pytesseract
        from PIL import ImageOps

        disponiveis = self.idiomas()
        if disponiveis and idioma not in disponiveis:
            idioma = "eng" if "eng" in disponiveis else disponiveis[0]

        preparada = ImageOps.autocontrast(ImageOps.grayscale(imagem))
        dados = pytesseract.image_to_data(
            preparada, lang=idioma, output_type=pytesseract.Output.DICT, config="--psm 6"
        )

        agrupadas: dict[tuple, dict] = {}
        for i, palavra in enumerate(dados["text"]):
            palavra = palavra.strip()
            if not palavra:
                continue
            try:
                confianca = float(dados["conf"][i])
            except (ValueError, TypeError):
                confianca = -1
            if confianca < confianca_minima:
                continue
            chave = (dados["block_num"][i], dados["par_num"][i], dados["line_num"][i])
            registro = agrupadas.setdefault(chave, {
                "texto": "", "topo": dados["top"][i], "esquerda": dados["left"][i],
                "base": dados["top"][i] + dados["height"][i],
                "direita": dados["left"][i] + dados["width"][i],
                "confianca": confianca, "soma": 0.0, "quantidade": 0,
            })
            registro["texto"] = (registro["texto"] + " " + palavra).strip()
            registro["esquerda"] = min(registro["esquerda"], dados["left"][i])
            registro["base"] = max(registro["base"], dados["top"][i] + dados["height"][i])
            registro["direita"] = max(registro["direita"],
                                      dados["left"][i] + dados["width"][i])
            registro["soma"] += confianca
            registro["quantidade"] += 1

        for registro in agrupadas.values():
            if registro["quantidade"]:
                registro["confianca"] = registro["soma"] / registro["quantidade"]
        return list(agrupadas.values())


# A ordem é a preferência quando nenhum motor foi escolhido à mão.
#
# RapidOCR vem primeiro por dois motivos. Ele reporta a confiança de cada
# leitura — sem isso o sistema não consegue avisar "leitura duvidosa" nem
# descartar ruído de ícone, que são duas defesas importantes. E, nas peças
# testadas, errou menos: onde o motor do Windows devolveu "Estreias
# deseeerpbro", ele leu "Estreias de setembro".
#
# O do Windows continua disponível e tem uma vantagem real: acentua certo,
# porque tem português nativo. Vale testar os dois nas suas peças e fixar o
# melhor com a variável OCR_MOTOR.
MOTORES = [MotorRapidOCR(), MotorWindows(), MotorTesseract()]
_ESCOLHIDO = None
_DIAGNOSTICO = None


def diagnosticar() -> list[dict]:
    """Estado de cada motor, para a tela mostrar o que falta instalar."""
    global _DIAGNOSTICO
    if _DIAGNOSTICO is None:
        _DIAGNOSTICO = []
        for motor in MOTORES:
            ok, motivo = motor.disponivel()
            _DIAGNOSTICO.append({
                "nome": motor.nome, "descricao": motor.descricao,
                "disponivel": ok, "motivo": motivo,
            })
    return _DIAGNOSTICO


# motor escolhido na tela, válido só para a conferência em curso
_FORCADO_NA_TELA = ""
_AVISO_DE_ESCOLHA = ""


def aviso_de_escolha() -> str:
    """Explica por que o motor em uso não é o que foi pedido."""
    return _AVISO_DE_ESCOLHA


def forcar_motor(nome: str) -> None:
    """Fixa o motor para as próximas leituras. Vazio volta à preferência padrão."""
    global _FORCADO_NA_TELA, _ESCOLHIDO
    nome = (nome or "").strip().lower()
    if nome != _FORCADO_NA_TELA:
        _FORCADO_NA_TELA = nome
        _ESCOLHIDO = None        # refaz a escolha na próxima leitura


def motores_disponiveis() -> list[dict]:
    return [d for d in diagnosticar() if d["disponivel"]]


def motor_ativo():
    """Escolhe o motor: o forçado à mão, ou o primeiro disponível da lista."""
    global _ESCOLHIDO
    if _ESCOLHIDO is not None:
        return _ESCOLHIDO or None

    global _AVISO_DE_ESCOLHA
    _AVISO_DE_ESCOLHA = ""

    forcado = (_FORCADO_NA_TELA
               or (os.environ.get("OCR_MOTOR") or "").strip().lower())

    if forcado:
        pedido = next((m for m in MOTORES if m.nome == forcado), None)
        if pedido is None:
            _AVISO_DE_ESCOLHA = (
                f"O motor \u201c{forcado}\u201d não existe. "
                f"Use um destes: {', '.join(m.nome for m in MOTORES)}."
            )
        else:
            ok, motivo = pedido.disponivel()
            if ok:
                _ESCOLHIDO = pedido
                return pedido
            # Pedir um motor que não está instalado não pode desligar a leitura
            # inteira: o certo é usar o que existe e dizer por que não foi o
            # escolhido. Desligar em silêncio faz parecer defeito do sistema.
            _AVISO_DE_ESCOLHA = (
                f"Você pediu o motor \u201c{forcado}\u201d, mas ele não está "
                f"disponível ({motivo})."
            )

    for motor in MOTORES:
        ok, _ = motor.disponivel()
        if ok:
            _ESCOLHIDO = motor
            return motor
    _ESCOLHIDO = False
    return None


def ocr_disponivel() -> tuple[bool, str]:
    motor = motor_ativo()
    if motor:
        aviso = aviso_de_escolha()
        if aviso:
            return True, f"{aviso} Usando {motor.descricao}."
        return True, f"{motor.descricao} ativo"
    faltas = "; ".join(f"{d['nome']}: {d['motivo']}" for d in diagnosticar())
    return False, f"nenhum motor de leitura disponível ({faltas})"


def idiomas_instalados() -> list[str]:
    motor = motor_ativo()
    if isinstance(motor, MotorTesseract):
        return motor.idiomas()
    if motor:
        return ["por"]  # Windows e RapidOCR cobrem o alfabeto latino
    return []


# Ícone de rede social, marcador de lista, pixel espaçador. Não cabe texto
# legível num quadrado de 20 px, e cada um desses custa meio segundo de
# leitura à toa — num pacote com dez ícones, são cinco segundos de espera.
LADO_MINIMO_PARA_LER = 60
AREA_MINIMA_PARA_LER = 2500


def _pequena_demais(caminho: str) -> tuple[bool, str]:
    try:
        from PIL import Image
        with Image.open(caminho) as imagem:
            largura, altura = imagem.size
    except Exception:
        return False, ""
    if largura * altura < AREA_MINIMA_PARA_LER:
        return True, f"{largura}x{altura}: pequena demais para conter texto"
    if largura < LADO_MINIMO_PARA_LER and altura < LADO_MINIMO_PARA_LER:
        return True, f"{largura}x{altura}: tamanho de ícone"
    return False, ""


def _e_gif_animado(caminho: str) -> bool:
    if not caminho.lower().endswith(".gif"):
        return False
    try:
        from PIL import Image
        with Image.open(caminho) as imagem:
            return getattr(imagem, "n_frames", 1) > 1
    except Exception:
        return False


def ler_imagem(caminho: str, idioma: str = "por",
               confianca_minima: int = 40) -> ResultadoOCR:
    motor = motor_ativo()
    nome = os.path.basename(caminho)
    if not motor:
        return ResultadoOCR(arquivo=nome, erro=ocr_disponivel()[1])

    pequena, motivo = _pequena_demais(caminho)
    if pequena:
        return ResultadoOCR(arquivo=nome, lido=True, motor=motor.nome, aviso=motivo)

    if not _e_gif_animado(caminho):
        return motor.ler(caminho, idioma, confianca_minima)

    # GIF animado: cada cena pode trazer texto próprio, e é comum a oferta
    # inteira estar espalhada entre os frames.
    import tempfile

    textos, confiancas, frames_lidos = [], [], 0
    try:
        quadros = _frames_relevantes(caminho)
    except Exception as e:
        return ResultadoOCR(arquivo=nome, erro=f"não consegui abrir o GIF: {e}",
                            motor=motor.nome)

    with tempfile.TemporaryDirectory(prefix="frames_") as pasta:
        for indice, quadro in enumerate(quadros):
            destino = os.path.join(pasta, f"frame_{indice:02d}.png")
            try:
                quadro.save(destino)
            except Exception:
                continue
            parcial = motor.ler(destino, idioma, confianca_minima)
            if parcial.texto:
                textos.append(parcial.texto)
                frames_lidos += 1
            if parcial.confianca_media:
                confiancas.append(parcial.confianca_media)

    texto = _juntar_textos(textos)
    return ResultadoOCR(
        arquivo=nome, texto=texto, lido=True, motor=motor.nome,
        linhas=texto.splitlines(),
        confianca_media=round(sum(confiancas) / len(confiancas), 1) if confiancas else 0.0,
        aviso=(f"GIF animado: {frames_lidos} cena(s) lida(s) de "
               f"{len(quadros)} frame(s) distintos"),
    )


# ------------------------------------------------------- cache entre execuções

PASTA_CACHE = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".cache-leitura"
)

# Sobe quando a leitura muda de comportamento, para o cache antigo não valer.
VERSAO_DA_LEITURA = "3"


def _impressao_do_arquivo(caminho: str, motor: str) -> str | None:
    """
    Identidade da leitura: conteúdo do arquivo + motor + versão.

    Pelo conteúdo, e não pelo caminho: o mesmo banner reaparece em campanhas
    diferentes com nomes diferentes, e conferir de novo o que já foi lido é
    desperdício. Muda uma vírgula na imagem, muda a impressão.
    """
    import hashlib

    try:
        digestor = hashlib.sha1()
        with open(caminho, "rb") as arquivo:
            for pedaco in iter(lambda: arquivo.read(262144), b""):
                digestor.update(pedaco)
    except OSError:
        return None
    digestor.update(f"|{motor}|{VERSAO_DA_LEITURA}".encode())
    return digestor.hexdigest()


def _ler_do_cache(impressao: str) -> ResultadoOCR | None:
    if not impressao:
        return None
    import json

    caminho = os.path.join(PASTA_CACHE, f"{impressao}.json")
    try:
        with open(caminho, encoding="utf-8") as arquivo:
            dados = json.load(arquivo)
        return ResultadoOCR(**dados)
    except Exception:
        return None


def _gravar_no_cache(impressao: str, resultado: ResultadoOCR) -> None:
    if not impressao or resultado.erro:
        return          # falha não entra no cache: a próxima tentativa pode dar certo
    import json
    from dataclasses import asdict

    try:
        os.makedirs(PASTA_CACHE, exist_ok=True)
        caminho = os.path.join(PASTA_CACHE, f"{impressao}.json")
        with open(caminho, "w", encoding="utf-8") as arquivo:
            json.dump(asdict(resultado), arquivo, ensure_ascii=False)
    except OSError:
        pass            # sem permissão de escrita: segue sem cache


class CacheOCR:
    """
    Guarda a leitura de cada imagem, dentro da execução e entre execuções.

    Ler imagem é praticamente todo o tempo da conferência. Na prática o mesmo
    pacote é conferido várias vezes — ajusta o docx, confere de novo — e as
    imagens não mudaram. Reler tudo a cada vez é o desperdício mais caro aqui.
    """

    def __init__(self, idioma: str = "por", confianca_minima: int = 40,
                 usar_disco: bool = True):
        self.idioma = idioma
        self.confianca_minima = confianca_minima
        self.usar_disco = usar_disco
        self.aviso_idioma = ""
        self.reaproveitadas = 0
        self._cache: dict[str, ResultadoOCR] = {}

    def _nome_do_motor(self) -> str:
        motor = motor_ativo()
        return motor.nome if motor else "nenhum"

    def ler(self, caminho: str) -> ResultadoOCR:
        chave = os.path.normcase(os.path.abspath(caminho))
        if chave in self._cache:
            return self._cache[chave]

        impressao = (_impressao_do_arquivo(caminho, self._nome_do_motor())
                     if self.usar_disco else None)
        guardado = _ler_do_cache(impressao) if impressao else None
        if guardado is not None:
            self.reaproveitadas += 1
            self._cache[chave] = guardado
            return guardado

        resultado = ler_imagem(caminho, self.idioma, self.confianca_minima)
        if resultado.aviso and not self.aviso_idioma:
            self.aviso_idioma = resultado.aviso
        if impressao:
            _gravar_no_cache(impressao, resultado)
        self._cache[chave] = resultado
        return resultado

    def pre_carregar(self, caminhos: list[str], trabalhadores: int = 3,
                     ao_avancar=None) -> None:
        """
        Lê várias imagens ao mesmo tempo.

        O reconhecimento roda fora do Python, então a espera de uma imagem não
        impede a leitura da outra — ler quatro em paralelo aproveita a máquina
        em vez de ficar na fila.
        """
        pendentes = []
        for caminho in caminhos:
            chave = os.path.normcase(os.path.abspath(caminho))
            if chave not in self._cache and os.path.exists(caminho):
                pendentes.append(caminho)
        total = len(pendentes)
        if total < 2:
            for caminho in pendentes:
                self.ler(caminho)
                if ao_avancar:
                    ao_avancar(1, total)
            return

        from concurrent.futures import ThreadPoolExecutor

        concluidas = 0
        with ThreadPoolExecutor(max_workers=min(trabalhadores, total)) as pool:
            for _ in pool.map(self.ler, pendentes):
                concluidas += 1
                if ao_avancar:
                    ao_avancar(concluidas, total)

    @property
    def lidas(self) -> int:
        return sum(1 for r in self._cache.values() if r.lido)
